// Sample Java GhidraScript
// @category Examples
import ghidra.app.script.GhidraScript;

public class SampleScript extends GhidraScript {

	@Override
	protected void run() throws Exception {
    	println("Sample script!");
	}
}
